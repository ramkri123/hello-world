# llm-bootcamp

This is a repository for the LLM Bootcamp projects. 
It contains partial solutions to the exercises and projects.

Please run the following commands before trying out the code in this solution:

pip install -r requirements.txt
pip install -e .
