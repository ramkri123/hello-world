Elastic-Setup Demo
--------------------



.. toctree::
   :maxdepth: 2
   :caption: Content:

   
   elastic-search-notes



