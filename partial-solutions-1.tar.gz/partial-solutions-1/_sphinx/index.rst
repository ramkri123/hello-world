.. LLM-Bootcamp documentation master file, created by
   sphinx-quickstart on Fri Sep 29 11:04:42 2023.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.
.. image:: logo.png
  :width: 300
  :height: 200
  :align: center
  :alt: supportvector logo
  
Welcome to LLM-Bootcamp's documentation!
========================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

.. include:: modules.rst
.. include:: text-extraction-nb.rst
.. include:: es-setup-nb.rst






Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
