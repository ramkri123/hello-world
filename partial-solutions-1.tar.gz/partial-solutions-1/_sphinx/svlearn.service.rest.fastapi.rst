svlearn.service.rest.fastapi package
====================================

Submodules
----------

svlearn.service.rest.fastapi.clean\_chunk\_fastapi\_service module
-------------------------------------------------------------------

.. automodule:: svlearn.service.rest.fastapi.clean_chunk_fastapi_service
   :members:
   :undoc-members:
   :show-inheritance:

svlearn.service.rest.fastapi.faiss\_fastapi\_index\_builder\_service module
---------------------------------------------------------------------------

.. automodule:: svlearn.service.rest.fastapi.faiss_fastapi_index_builder_service
   :members:
   :undoc-members:
   :show-inheritance:


svlearn.service.rest.fastapi.sentence\_embedding\_fastapi\_service module
-------------------------------------------------------------------------

.. automodule:: svlearn.service.rest.fastapi.sentence_embedding_fastapi_service
   :members:
   :undoc-members:
   :show-inheritance:




Module contents
---------------

.. automodule:: svlearn.service.rest.fastapi
   :members:
   :undoc-members:
   :show-inheritance:
