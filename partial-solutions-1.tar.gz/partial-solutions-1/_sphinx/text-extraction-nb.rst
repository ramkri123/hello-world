Text-Extraction Demo
--------------------



.. toctree::
   :maxdepth: 2
   :caption: Contents:

   demo



