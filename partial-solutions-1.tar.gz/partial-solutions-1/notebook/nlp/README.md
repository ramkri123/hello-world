# nlp
The Natural Language Processing Workshop

This project contains the labs associated with the NLP with transformers workshop:https://supportvectors.com/index.php/natural-language-processing/
