"""
All the services are defined here: currently, we have the REST API service.
Going forward, we may add gRPC, or other services.
"""